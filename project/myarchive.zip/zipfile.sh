zip -r myarchive.zip . -x "*.zip"
